Gait Sub Phases - Walking

This file is supplied to illustrate the normal operation of the Nexus to Python 3.9 interface.
Oxford Metrics and Vicon Motion Systems accept no responsibility for its
correct operation

This code can be used to identify the subphases of the gait cycle. The user will be prompted to select subjects name
from a dropdown menu and an excel spreadsheet will be generated containing the gait cycle events.

This code works by using the LASI and RASI markers. The foot strikes and the foot offs for the left and right leg must
already be accurately placed in the trial for this script to work.

The gait cycle events must be entered in this order:

1. Ipsilateral foot-strike 1
2. Contralateral foot-off
3. Contralateral foot-strike
4. Ipsilateral foot-off
5. Ipsilateral foot-strike 2

There will be four sheets in the spreadsheet, one for the left and right leg respectively. Each sheet will contain
the following gait events for each walking gait cycle:

- Ipsilateral foot-strike 1
- Contralateral foot-off
- Ipsilateral mid-stance
- Contralateral foot-strike
- Ipsilateral foot-off
- Ipsilateral mid-swing
- Ipsilateral foot-strike 2

The following two sheets will have the percentage of the gait cycle where the gait cycle subphases occur. 

These gait cycle subphases will be written to Nexus in the Analysis parameters. The average and standard deviations 
will also be recorded. 

The mid-stance and mid-swing will also be added to the time bar event as "General events"

It is recommended to check the accuracy of the outputs

This code was written and tested on normal gait data only, and so,
its accuracy for pathological gait has not been verified

This code was written in Python 3.9, and to run this code, the following modules must be installed:

- numpy
- tkinter
- sys
- pandas

Written by Andrea Rivera and Nev Pires
This code will work based on the assumption that the foot strikes and foot offs have been properly
identified within the trial
The LASI and RASI markers must be present and labelled in the trial
Events will be calculated that fall between the gait cycle only. That is, between foot strike to foot strike
of the ipsi-lateral leg