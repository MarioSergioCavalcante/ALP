# Gait Sub Phases - Running
#
# This file is supplied to illustrate the normal operation of the Nexus to Python interface.
# Oxford Metrics and Vicon Motion Systems accept no responsibility for its
# correct operation
#
# This code can be used to identify the sub phases of the running gait cycle.
# The user will be prompted to select the subject name and
# an Excel spreadsheet will be generated containing the running sub-phases events represented as frames and the
# percentage of the gait cycle where the gait subphases occur. The average and standard deviation will also
# be calculated. The % of the gait cycle will be written to the "Analysis parameters" in Nexus. The stance and swing
# phases will be written to the time bar as "General Events"
#
# This code works by using the LASI and RASI markers. The foot strikes and the foot offs for the left and right leg must
# already be accurately placed in the trial for this script to work.
# The first two sheets in the spreadsheet, will display the time bar events in frames. Each sheet will contain
# the following running events for each running cycle:
#
# - Ipsilateral foot-strike 1
# - Ipsilateral mid-stance
# - Ipsilateral foot-off
# - Contralateral foot-strike
# - Ipsilateral mid-swing
# - Contralateral foot-off
# - Ipsilateral foot-strike 2
#
# The % of the gait cycle at which the events occur will be written to separate Excel sheets for the left and right leg
#
# The mid-stance and mid-swing events will be written to Nexus as General Events
#
# The gait cycle parameters will also be written to Nexus. These will include the average and standard deviation
#
# It is recommended to check the accuracy of the outputs
#
# This code was written and tested on normal running treadmill data only, and so, its accuracy for pathological
# walking has not been verified
# To run this code, the following modules must be installed:
#
# - numpy
# - tkinter
# - sys
# - pandas
# - viconnexusutils
# - viconnexusapi
#
# Written by Nev Pires and Andrea Rivera 
# This code will work based on the assumption that the foot strikes
# and foot offs have been properly identified within the trial
# The LASI and RASI markers must be present and labelled in the trial
# Events will be calculated that fall between the running cycle only.
# That is, between foot strike to foot strike of the ipsilateral leg

import pandas as pd
import numpy as np

import tkinter as tk
from tkinter import ttk, Button
import tkinter.messagebox

from scipy.signal import find_peaks

import sys
from viconnexusapi import ViconNexus

# Import Nexus Trajectories
from viconnexusutils import NexusTrajectory

# Connect to Nexus
vicon = ViconNexus.ViconNexus()

# Get the file name
file_path = vicon.GetTrialName()[0]
file_name = vicon.GetTrialName()[1]

# Check to see if there is a VSK in the trial. If there is no subject in the trial, an error will be generated
if not vicon.GetSubjectNames():
    tk.messagebox.showwarning(title=None, message='The trial does not contain a subject')
    sys.exit('The trial does not contain a subject. Please return to Nexus and load a subject')

# Get subject list.
subject_list = vicon.GetSubjectNames()

# Define the GUI
root = tk.Tk()
root.resizable(True, True)
root.title("Enter Inputs")

# Create the subject dropdown menu and label
subject_header = ttk.Label(root, text="Subject Name", font=('Courier', 12), relief="raised")
subject_header.grid(column=0, row=0)

subject_menu = tk.StringVar()
subject_menu.set('Select Subject')

subject_selection = tk.OptionMenu(root, subject_menu, *subject_list)
subject_selection.grid(column=0, row=1)

# Create the submit button
subject = []


def submit():
    global subject
    subject = subject_menu.get()
    root.destroy()


submit_button: Button = tk.Button(root, text='Submit', command=submit)
submit_button.grid(column=2, row=2)

# Display the GUI
root.mainloop()

# Check to see that the subject was selected
if subject not in vicon.GetSubjectNames():
    tk.messagebox.showwarning(title=None,
                              message='The Subject Name does not match the VSK. '
                                      'Please select the correct Subject Name from the dropdown')

# Import the gait cycle events
context = {"Left", "Right"}

foot_strikes = {side: vicon.GetEvents(subject, side, "Foot Strike")[0] for side in context}
foot_offs = {side: vicon.GetEvents(subject, side, "Foot Off")[0] for side in context}

# Get the first and last foot strikes
first_foot_strike = min([min([event for event in foot_strikes[side]]) for side in context])
last_foot_strike = max([max([event for event in foot_strikes[side]]) for side in context])

# Import LASI and RASI markers
ASIS_marker_names = ["LASI", "RASI"]
ASIS_markers = {names: NexusTrajectory.NexusTrajectory(subject) for names in ASIS_marker_names}
_ = {names: ASIS_markers[names].Read(names, vicon) for names in ASIS_marker_names}

# Calculate the PelO marker as the midpoint between the LASI and RASI markers. Only extract the Z component
# and crop to the first and last gait cycle events and find the frames at which the minimum values appear
# minimum values represent mid-stance and mid-swing respectively
pel_o_z_mins = find_peaks((-np.array(ASIS_markers["LASI"].Position())[:, 2] +
                           -np.array(ASIS_markers["RASI"].Position())[:, 2]) / 2)[0]

# Crop the pel_o_z_mins to between the first and last foot strikes
pel_o_z_mins = [event for event in pel_o_z_mins if first_foot_strike < event < last_foot_strike]

# Combine all the events to one array
gait_events = [foot_strikes["Left"] +
               foot_strikes["Right"] +
               foot_offs["Left"] +
               foot_offs["Right"] +
               list(pel_o_z_mins)][0]
gait_events.sort()

# Identify the start and end points of the running cycle
gait_cycle_start = {side: [foot_strikes[side][cycle] for cycle in range(len(foot_strikes[side]) - 1)]
                    for side in context}

gait_cycle_end = {side: [foot_strikes[side][cycle + 1] for cycle in range(len(foot_strikes[side]) - 1)] for side in
                  context}

# Allocate the gait cycle data that falls between the bounds of each gait cycle
gait_cycle_events = {side:
                         {"Gait Cycle " + str(cycle + 1).zfill(3):
                              [event for event in gait_events
                               if gait_cycle_start[side][cycle] <= event <= gait_cycle_end[side][cycle]]
                          for cycle in range(len(gait_cycle_start[side]))} for side in context}

# Compile gait cycle events into a compiled array to be exported
gait_cycle_events_compiled = {side: np.array([events for _, events in sorted(gait_cycle_events[side].items())])
                              for side in context}

# Determine the subphase names
subphase_names = ["ipsilateral foot strike 1",
                  "ipsilateral mid stance",
                  "ipsilateral foot off",
                  "contralateral foot strike",
                  "ipsilateral mid swing",
                  "contralateral foot off",
                  "ipsilateral foot strike 2"]

# Define the gait cycle subphases
gait_subphases = {side: {name: {cycle: gait_cycle_events[side][cycle][event]
                                for cycle in gait_cycle_events[side]}
                         for event, name in enumerate(subphase_names)}
                  for side in context}

# Export mid-stance and mid-swing to Nexus
_ = {side: {cycle: vicon.CreateAnEvent(subject,
                                       side,
                                       'General',
                                       int(gait_subphases[side]["ipsilateral mid stance"][cycle]),
                                       0)
            for cycle in gait_cycle_events[side]}
     for side in context}

_ = {side: {cycle: vicon.CreateAnEvent(subject,
                                       side,
                                       'General',
                                       int(gait_subphases[side]["ipsilateral mid swing"][cycle]),
                                       0)
            for cycle in gait_cycle_events[side]}
     for side in context}

# Calculate the percentages of the gait cycle
percent_compiled = {"mid stance %": {side:
    {cycle: np.round(
        np.divide(gait_subphases[side]["ipsilateral mid stance"][cycle]
                  - gait_subphases[side]["ipsilateral foot strike 1"][cycle],
                  gait_subphases[side]["ipsilateral foot strike 2"][cycle]
                  - gait_subphases[side]["ipsilateral foot strike 1"][
                      cycle]) * 100,
        2)
        for cycle in gait_cycle_events[side]}
    for side in context},
    "stance phase %": {side:
        {cycle: np.round(
            np.divide(gait_subphases[side]["ipsilateral foot off"][cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][cycle],
                      gait_subphases[side]["ipsilateral foot strike 2"][cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][
                          cycle]) * 100, 2)
            for cycle in gait_cycle_events[side]}
        for side in context},
    "contralateral foot strike %": {side:
        {cycle: np.round(
            np.divide(gait_subphases[side]["contralateral foot strike"][cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][cycle],
                      gait_subphases[side]["ipsilateral foot strike 2"][cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][
                          cycle]) * 100, 2)
            for cycle in gait_cycle_events[side]}
        for side in context},
    "ipsilateral mid swing %": {side:
        {cycle: np.round(
            np.divide(gait_subphases[side]["ipsilateral mid swing"][cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][
                          cycle],
                      gait_subphases[side]["ipsilateral foot strike 2"][
                          cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][
                          cycle]) * 100, 2)
            for cycle in gait_cycle_events[side]}
        for side in context},
    "contralateral foot off %": {side:
        {cycle: np.round(
            np.divide(gait_subphases[side]["contralateral foot off"][cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][
                          cycle],
                      gait_subphases[side]["ipsilateral foot strike 2"][
                          cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][
                          cycle]) * 100, 2)
            for cycle in gait_cycle_events[side]}
        for side in context},
    "swing phase %": {side:
        {cycle: np.round(
            np.divide(gait_subphases[side]["ipsilateral foot strike 2"][cycle]
                      - gait_subphases[side]["ipsilateral foot off"][cycle],
                      gait_subphases[side]["ipsilateral foot strike 2"][cycle]
                      - gait_subphases[side]["ipsilateral foot strike 1"][
                          cycle]) * 100,
            2)
            for cycle in gait_cycle_events[side]}
        for side in context}}

# Create a list of percentage output names
percentage_names = list(percent_compiled.keys())

# Add the average and standard deviation to the percentage outputs
_ = {name: {side: percent_compiled[name][side].update({"Average":
                                                           np.round(np.mean([item for item in
                                                                             percent_compiled[name][side].values()]),
                                                                    2)})
            for side in context}
     for name in percentage_names}

_ = {name: {side: percent_compiled[name][side].update({"Std Dev":
                                                           np.round(np.std([item for item in
                                                                            percent_compiled[name][side].values()]),
                                                                    2)})
            for side in context}
     for name in percentage_names}

# Compile percentages into one dictionary
percentages = {side: np.array([[percent_compiled[name][side][cycle]
                                for cycle in percent_compiled[name][side]]
                               for name, value in percent_compiled.items()]).T
               for side in context}

# Combine the left and right data into np arrays for exporting to Excel
output_data = {side: pd.DataFrame(gait_cycle_events_compiled[side]) for side in context}
output_data_percentages = {side: pd.DataFrame(percentages[side]) for side in context}

# Create the column headers to be written to Excel running headers below
columnHeaders = pd.DataFrame(subphase_names).T

column_headers_percentages = pd.DataFrame(percent_compiled.keys()).T

# Create the row headers to be written to Excel
row_headers = {side: pd.DataFrame([names for names in gait_cycle_events[side].keys()]) for side in context}

row_headers_percentages = {side:
                               pd.DataFrame(np.array(np.append([names for names in gait_cycle_events[side].keys()],
                                                               ['Mean', 'Std Dev']))) for side in context}

# Create the file name with which to export the data
gaitSubphasesWriter = pd.ExcelWriter(file_path + file_name + '_Gait_Subphases.xlsx', engine='xlsxwriter')

# Write the data to Excel
[columnHeaders.to_excel(gaitSubphasesWriter, header=False, index=False, sheet_name=side + "_Frames", startcol=1)
 for side in context]
[row_headers[side].to_excel(gaitSubphasesWriter, header=False, index=False, sheet_name=side + "_Frames", startrow=1)
 for side in context]
[output_data[side].to_excel(gaitSubphasesWriter, header=False, index=False, sheet_name=side + "_Frames",
                            startcol=1, startrow=1) for side in context]

[column_headers_percentages.to_excel(gaitSubphasesWriter, header=False, index=False, sheet_name=side + "_Percentages",
                                     startcol=1) for side in context]
[row_headers_percentages[side].to_excel(gaitSubphasesWriter, header=False, index=False,
                                        sheet_name=side + "_Percentages", startrow=1) for side in context]
[output_data_percentages[side].to_excel(gaitSubphasesWriter, header=False, index=False,
                                        sheet_name=side + "_Percentages",
                                        startcol=1, startrow=1) for side in context]

# Save the created Excel file
gaitSubphasesWriter.save()

# Get analysis param list
analysis_param_names = vicon.GetAnalysisParamNames(subject)

# Flatten the percent compiled dictionary to make it easier to export to Nexus
percent_output = {side + " " + name + " " + cycle: percent_compiled[name][side][cycle]
                  for side in context for name in percentage_names
                  for cycle in percent_compiled[name][side].keys()}

# Write to Nexus
_ = {name: vicon.CreateAnalysisParam(subject, name, value, 'none') for name, value in percent_output.items()
     if name not in analysis_param_names}

# set analysis params if param exists but needs to be overwritten
_ = {name: vicon.SetAnalysisParam(subject, name, value) for name, value in percent_output.items()
     if name not in analysis_param_names}
