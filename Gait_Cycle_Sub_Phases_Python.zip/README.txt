Gait Sub Phases - Python

This file is supplied to illustrate the normal operation of the Nexus to Python 3.9 interface.
Oxford Metrics and Vicon Motion Systems accept no responsibility for its
correct operation. 

The two gait cycle codes are found in the Walking and Running subfolders respectively. 
These codes are called: 

- walking_sub_phases_v2
- running_sub_phases_v2

These codes can be used to identify the subphases of the walking or running gait cycle. The user will be prompted to select subjects name
from a dropdown menu and an excel spreadsheet will be generated containing the gait cycle events and the percentage of the
gait cycle where the subphases occur, including the average and standard deviation. 

This code works by using the LASI and RASI markers. The foot strikes and the foot offs for the left and right leg must
already be accurately placed in the trial for this script to work.

There will be four sheets in the spreadsheet. The first two display the frame at which the gait cycle events occur for 
the left and right legs. The second two sheets display the percentage of the gait cycle where the gait events occur, 
including the average and the standard deviations. 

The percentage of the gait cycle where the subphases occur will be written to the Analysis parameters in Nexus 2. 

THe mid-stance and mid-swing will be written to the time bar as "General Events".

It is recommended to check the accuracy of the outputs

This code was written and tested on normal gait data only, and so,
its accuracy for pathological gait has not been verified

To run this code, the following modules must be installed:

- numpy
- tkinter
- sys
- pandas
- viconnexusapi
- viconnexusutils

Written by Andrea Rivera and Nev Pires
This code will work based on the assumption that the foot strikes and foot offs have been properly
identified within the trial
The LASI and RASI markers must be present and labelled in the trial
Events will be calculated that fall between the gait cycle only. That is, between foot strike to foot strike
of the ipsi-lateral leg